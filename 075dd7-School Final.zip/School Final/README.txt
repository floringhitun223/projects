This is the final version of SCHOOL V. The updates for this map are ended.

Change Log:

- Retextured the hall-way
- Added a 2nd floor:
            - Added a Sport Room.
            - Added Janitor Room.
- The hall-way has been extended ( Added 3 more rooms)
            - Changed the location of the bathroom.
            - Added a new and bigger classroom.
            - Added a new small classroom.
- The Cafeteria structure has been modified
- All the classrooms has been modified.
- and more... 

INSTALLATION:

FIRST OF ALL YOU WILL NEED TO DOWNLOAD <"MENYOO TO YMAP CONVERTER">, <"MENYOO">, <"SCRIPTHOOK">, <"MAP BUILDER">. Sorry if i missed something.

1. Copy "part1.ymap" and "part2.ymap" to: UPDATE--->X64--->DLCPACKS--->CUSTOM_MAPS--->DLC.RPF--->X64--->LEVELS--->GTA5--->_CITYE--->MAPS--->CUSTOM_MAPS
2. Copy "SchoolFinal.xml" to: GTA 5 FOLDER--->MENYOOSTUFF--->SPOONER
3.In game, go to "Object Spooner->Manage Saved Files->click on "SchoolFinal"->Load Placements

NOTE: BECAUSE OF THIS UPDATE, THE NUMBER OF PROPS IS BIGGER THAN 2045, THAT MEANS THAT THE MENYOO SPOONER CANNOT LOAD MORE THAN 2045, SO I CONVERTED THE MAP IN YMAP. Be sure that, when you load the map, your pc is not overheating cuz of big amount of props. THE "SchoolFinal.xml" IS FOR SPAWNING TO THE LOCATION. IF YOU DON T WANT TO USE MENYOO(THAT IS JUST POINTLESS), JUST WITH .YMAP, JUST USE THIS CORDS:

<X>-1668.81616</X>

<Y>233.831223</Y>

<Z>1480.60925</Z>

THIS TIME THE MAP HAVE NO PEDS OF NPC'S. IS JUST AN EMPTY SCHOOL, YOU NEED TO MAKE YOUR OWN SCENARIO. 





                                      THANK YOU FOR READING THIS
                                                           WITH PLEASURE, DARON HUNTER
